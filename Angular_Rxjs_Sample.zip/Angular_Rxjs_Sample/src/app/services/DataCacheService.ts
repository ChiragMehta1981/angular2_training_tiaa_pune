import { Injectable } from '@angular/core';

// Service

@Injectable()

export default class DataCacheService
{
  private _ServiceId : number;

  constructor()
  {
    this._ServiceId = Math.random();
  }

  GetServiceId()
  {
    return this._ServiceId;
  }
}
