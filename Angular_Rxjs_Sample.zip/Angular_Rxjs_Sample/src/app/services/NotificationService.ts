import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';

// Service

@Injectable()

export default class NotificationService
{
  private _NotificationObservable : Observable<any>;
  private _NotificationObservers : any[];

  constructor()
  {
    this._NotificationObservers = [];

    this._NotificationObservable = new Observable<any>(
      (observer) => // .subscribe
      {
        this._NotificationObservers.push(observer);
      }
    )
  }

  ShowNotification(noticationMessage) // Consumer Components will call
  {

    this._NotificationObservers.forEach(
      (observer) =>
      {
        observer.next(noticationMessage);
      }
    )
  }

  Register()
  {
    return this._NotificationObservable;
  }
}
