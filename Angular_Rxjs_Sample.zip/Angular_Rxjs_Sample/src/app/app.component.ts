import { Component, HostListener } from '@angular/core';
import DataCacheService from './services/DataCacheService';
import NotificationService from './services/NotificationService';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent
{
  private _List : number[];
  private _NewNumber : number;

  constructor(private _NotificationService : NotificationService) //DI
  {
    //this._List = [8.1,3.34,6.456];
    this._List = [8, 3, 6];
    this._NewNumber = 0;

    //console.log("AppComponent: " + this._DataCacheService.GetServiceId());
  }

  @HostListener("mousewheel") HandleMouseWheel()
  {
    this._NotificationService.ShowNotification("Mouse Scrolled");
  }

  AddNumber()
  {
    this._List.push( this._NewNumber );

    // this._List =
    // [
    //   ...this._List,
    //   this._NewNumber
    // ];

    this._NewNumber = 0;

    this._NotificationService.ShowNotification("Add Number Completed");
  }

}
