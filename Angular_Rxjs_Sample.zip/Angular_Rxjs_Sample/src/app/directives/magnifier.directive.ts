import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive(
  {
    selector : '[magnifier]'
  }
)

export class MagnifierDirective
{
  private _Host: HTMLElement

  constructor(elementRef : ElementRef)
  {
    this._Host = elementRef.nativeElement;
  }

  ngOnInit()
  {
    this._Host.style.fontSize = this._Host.getAttribute('magnifierDefault');
    this._Host.style.transition = "font-size 0.5s";
  }

  @HostListener("mouseover") DirectiveMouseOver()
  {
      var fontSize = parseInt( this._Host.getAttribute('magnifierDefault').replace('px','') );

      var magnificationLevel =  parseInt( this._Host.getAttribute('magnifier') );

      this._Host.style.fontSize = (fontSize * magnificationLevel) + 'px';;
  }

  @HostListener("mouseout") DirectiveMouseOut()
  {
    this._Host.style.fontSize = this._Host.getAttribute('magnifierDefault');
  }
}
