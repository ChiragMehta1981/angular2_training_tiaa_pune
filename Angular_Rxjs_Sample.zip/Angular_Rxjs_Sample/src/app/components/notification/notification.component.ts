import { Component, OnInit } from '@angular/core';
import  NotificationService  from '../../services/NotificationService';


@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {

  constructor(private _NotificationService : NotificationService)
  {

  }

  ngOnInit()
  {
    var observable : any = this._NotificationService.Register();

    observable.subscribe(
        (message) => // next
        {
          alert(message);
        },
        (error) =>
        {

        },
        () =>
        {

        }
    )
  }

}


// var observer =
// {
//   next : function(message)
//   {

//   },
//   error  :function(error)
//   {

//   },
//   completed : function()
//   {

//   }
// }
