import { Component, Input, Output, EventEmitter, SimpleChange, OnInit, ElementRef} from '@angular/core';
//import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';
import DataCacheService from '../../services/DataCacheService';

@Component({
  selector: 'app-product-gallery',
  templateUrl: './product-gallery.component.html',
  styleUrls: ['./product-gallery.component.css']

})

export class ProductGalleryComponent //implements OnInit
{
  @Input() public products : string[];
  @Output() public onsaveproduct : EventEmitter<string>;
  @Input() public onsavesuccess : EventEmitter<string>;
  public _NewProduct : string;

  constructor(
    private _ElementRef : ElementRef,
    private _DataCacheService : DataCacheService
  ) // Dependency Injection(DI)
  {
    this.products = [];
    this.onsaveproduct = new EventEmitter<string>();
    this._NewProduct = "";
    this.onsavesuccess = new EventEmitter<string>();

    console.log("ProductGalleryComponent: " + this._DataCacheService.GetServiceId());
  }

  ngOnInit()
  {
    console.log("Child Component : ngOnInit");

    var temp =
    [
      ...this.products // spread (es6)
    ];

    this.products = temp;

    // this.onsavesuccess.subscribe(
    //   function cb(message)
    //   {
    //     alert(message);
    //     this._NewProduct = "";
    //     console.dir(this);
    //   }.bind(this) // product gallery component
    // )

    this.onsavesuccess.subscribe(
      (message) =>
      {
        alert(message);
        this._NewProduct = "";
        console.dir(this);
      }
    )
  }

  ngOnChanges(changes : SimpleChange)
  {
    console.group("Child Component : ngOnChanges");
    console.dir(changes);
    //console.dir(this.products);

    if(changes['products'] !== undefined)
    {
      var previousProducts = changes['products'].previousValue;
      var currentProducts = changes['products'].currentValue;

      if(previousProducts !== undefined)
      {
        var productRecentlyAdded = currentProducts[previousProducts.length];
        console.log(productRecentlyAdded);
      }

    }

    console.groupEnd();
  }

  ngDoCheck()
  {
   // console.log("Child Component: Do CHeck");
  }

  ngAfterViewInit()
  {
    var nativeDOMElement = this._ElementRef.nativeElement;
    nativeDOMElement.addEventListener(
      'mouseover',
      () =>
      {
        nativeDOMElement.style.color = "red";
      }
    )

    nativeDOMElement.addEventListener(
      'mouseout',
      () =>
      {
        nativeDOMElement.style.color = "";
      }

    )
  }

  SaveProduct()
  {
    this.onsaveproduct.emit(this._NewProduct); // Event Raised
  }

}
