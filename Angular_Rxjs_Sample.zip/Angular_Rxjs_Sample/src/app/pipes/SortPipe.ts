import { Pipe, PipeTransform } from '@angular/core';

@Pipe(
  {
    name : 'sort',
    pure : false
  }
)

export default class SortPipe implements PipeTransform
{
  private _SortPromise : Promise<any>;

  constructor()
  {

  }

  // transform(data : number[] , params : any[]) : number[]
  // {
  //     console.log('SortPipe : transform');

  //     var isAscending = params[0];

  //     var sortedData =
  //     [
  //       ...data
  //     ];

  //     var result;

  //     if(isAscending)
  //     {
  //       result = sortedData.sort();
  //     }
  //     else
  //     {
  //       result = sortedData.sort().reverse();
  //     }

  //     return result;
  // }

  transform(data : number[] , params : any[]) : Promise<any>
  {
    console.log('SortPipe : transform');

    if(!this._SortPromise)
    {
      this._SortPromise = new Promise(
        (resolve,reject) =>
        {
            setTimeout(
              () =>
              {
                  var isAscending = params[0];

                  var sortedData =
                  [
                    ...data
                  ];

                  var result;

                  if(isAscending)
                  {
                    result = sortedData.sort();
                  }
                  else
                  {
                    result = sortedData.sort().reverse();
                  }

                  //return result;
                  resolve(result);
              },
              2000
          )
        }
      );
    }

    return this._SortPromise;
  }
}
