import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { WidgetModule } from './modules/widgets.module';

import { AppComponent } from './app.component';

//Pipes
import SortPipe from './pipes/SortPipe';

//Services
import DataCacheService from './services/DataCacheService';
import { NotificationComponent } from './components/notification/notification.component';
import NotificationService from './services/NotificationService';

@NgModule(

  {
    declarations:
    [
      AppComponent,
      SortPipe,
      NotificationComponent
    ],

    imports:
    [
      BrowserModule,
      FormsModule,
      WidgetModule
    ],

    exports :
    [
    ],

    providers:
    [
      //DataCacheService // new DataCacheService()
      NotificationService
    ],

    bootstrap:
    [
      AppComponent
    ]

  }

)

export class AppModule { }
