import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ProductGalleryComponent } from './components/product-gallery/product-gallery.component';
import EVentoryComponent from './components/EnventoryComponent/enventory.component';
import { ProductListComponent } from './components/product-list/product-list.component';

@NgModule(

  {
    declarations:
    [
      AppComponent,
      ProductGalleryComponent,
      EVentoryComponent,
      ProductListComponent
    ],

    imports:
    [
      BrowserModule,
      FormsModule
      //,
      //BloombergModule
    ],

    exports :
    [
      EVentoryComponent
    ],

    providers:
    [

    ],

    bootstrap:
    [
      AppComponent,
      EVentoryComponent
    ]

  }

)

export class AppModule { }
