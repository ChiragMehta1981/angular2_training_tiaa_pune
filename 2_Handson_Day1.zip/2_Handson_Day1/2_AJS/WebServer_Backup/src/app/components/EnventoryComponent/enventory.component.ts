import { Component } from "@angular/core";


@Component(
  {
      selector : 'eventory',
      // template :
      // `
      //   <div>
      //     <h1>
      //         EVentory App
      //     </h1>
      //   </div>
      // `
      templateUrl : './enventory.component.html',
      // styles :
      // [
      //          `
      //           .header
      //           {
      //             background : yellow
      //           }
      //          `
      // ],
      styleUrls :
      [
          "./enventory.component.css"
      ]
  }
)

// Data Model (TS Class)
export default class EVentoryComponent
{
  // Type Declarations
  private AppName : string;
  private ShowAppVersion : boolean;

  constructor()
  {
    this.AppName = "Eventory Application";
    this.ShowAppVersion=true;
  }

  OnShowAppVersionChanged(event) //object prototype level
  {
    this.ShowAppVersion = event.target.value;
  }
}
