import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive(
  {
    selector : '[magnifier]'
  }
)

export class MagnifierDirective
{
  constructor(private _ElementRef : ElementRef)
  {
  }

  @HostListener("mouseover") DirectiveMouseOver()
  {
      var nativeElement = this._ElementRef.nativeElement;

      var fontSize = nativeElement.style.fontSize.replace('px','');
      fontSize = parseInt(fontSize);

      var magnificationLevel = nativeElement.getAttribute('magnifier') || 0;
      magnificationLevel = parseInt(magnificationLevel);

      var font = (fontSize * magnificationLevel) + 'px';
      nativeElement.style.fontSize = font;
  }

  // ngOnInit()
  // {
  //     var nativeElement = this._ElementRef.nativeElement;

  //     nativeElement.addEventListener(
  //       'mouseover',
  //       function Mouseover() // Function +nativeElement = CLosure
  //       {
  //         // var fontSize = nativeElement.style.fontSize.replace('px','');
  //         // fontSize = parseInt(fontSize);

  //         // var magnificationLevel = nativeElement.getAttribute('magnifier') || 0;
  //         // magnificationLevel = parseInt(magnificationLevel);

  //         // var font = (fontSize * magnificationLevel) + 'px';
  //         // nativeElement.style.fontSize = font;

  //         nativeElement.style.fontSize = "50px";
  //       }
  //     )

  //     nativeElement.addEventListener(
  //       'mouseout',
  //       function Mouseover()
  //       {
  //         nativeElement.style.fontSize = "10px";
  //       }
  //     )
  // }
}
