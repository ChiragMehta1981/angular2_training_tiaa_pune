import { Component, OnInit, ViewEncapsulation, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
  encapsulation : ViewEncapsulation.Native
})
export class ProductListComponent
{
    public _Products : string[];
    public _onSuccess: EventEmitter<string>;

  constructor()
  {
    this._Products =
    [
      "Mobiles",
      "Tablets",
      "Laptops"
    ];

    this._onSuccess = new EventEmitter<string>();
  }

  ngDoCheck()
  {
    console.log("Parent Component: Do Check");
  }

  SaveProduct(newProduct : string)
  {
    var matched = this._Products.indexOf(newProduct);

    if(matched == -1)
    {

      //this._Products.push(newProduct);

      this._Products =
      [
          ...this._Products,
          newProduct
      ];

      this._onSuccess.emit("Product Added Successfully");
    }
    else
    {
      // dup
      this._onSuccess.emit("Product already exists");
    }


  }
}
