import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { WidgetModule } from './modules/widgets.module';

import { AppComponent } from './app.component';

@NgModule(

  {
    declarations:
    [
      AppComponent
    ],

    imports:
    [
      BrowserModule,
      WidgetModule
    ],

    exports :
    [
    ],

    providers:
    [
    ],

    bootstrap:
    [
      AppComponent
    ]

  }

)

export class AppModule { }
