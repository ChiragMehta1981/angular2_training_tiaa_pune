import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { ProductGalleryComponent } from '../components/product-gallery/product-gallery.component';
import { ProductListComponent } from '../components/product-list/product-list.component';

import { MagnifierDirective } from '../directives/magnifier.directive';

@NgModule(

  {
    declarations:
    [
      ProductGalleryComponent,
      ProductListComponent,
      MagnifierDirective
    ],

    imports:
    [
      BrowserModule,
      FormsModule
    ],

    exports :
    [
      ProductGalleryComponent,
      ProductListComponent,
      MagnifierDirective
    ],

    providers:
    [
    ],

    bootstrap:
    [
    ]

  }

)

export class WidgetModule { }
