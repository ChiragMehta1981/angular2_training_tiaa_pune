import { Component, Renderer } from '@angular/core';

// Decorator
@Component(
    {
        selector : 'parent',
        moduleId : module.id,
        templateUrl : "ParentTemplate.html" 
    }
)

export class ParentComponent
{
    ChildItems : string[];
    NewItem : string;
    TimeStamp : string;

    constructor(private renderer: Renderer)
    {
        this.ChildItems = 
        [
            "Honda",
            "Toyota",
            "Nissan"
        ];

        this.NewItem = "";

        this.TimeStamp = new Date().toLocaleTimeString();
    }

    Save()
    {
        // Memory Ref of Parent Array not changed
        // Therefore ngOnChanges of Child Component WONT get called
        this.ChildItems.push( this.NewItem );
        
        // Memory Ref of Parent Array has changed
        // Therefore ngOnChanges of Child Component WILL get called
        // this.ChildItems = 
        // [
        //     ...this.ChildItems,
        //     this.NewItem
        // ]

        this.NewItem = "";
    }

    
    ngAfterContentInit()
    {
        console.log("Parent: ngAfterContentInit");
    }
    
    ngAfterContentChecked()
    {
        console.log("Parent: ngAfterContentChecked");
    }

    // View
    ngAfterViewInit()
    {
        console.log("Parent: ngAfterViewInit");
        //this.renderer.setElementStyle(this,"background","yellow");
    }

    ngAfterViewChecked()
    {
        console.log("Parent: ngAfterViewChecked");
    }
}

