"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
// Decorator
var ParentComponent = (function () {
    function ParentComponent(renderer) {
        this.renderer = renderer;
        this.ChildItems =
            [
                "Honda",
                "Toyota",
                "Nissan"
            ];
        this.NewItem = "";
        this.TimeStamp = new Date().toLocaleTimeString();
    }
    ParentComponent.prototype.Save = function () {
        // Memory Ref of Parent Array not changed
        // Therefore ngOnChanges of Child Component WONT get called
        this.ChildItems.push(this.NewItem);
        // Memory Ref of Parent Array has changed
        // Therefore ngOnChanges of Child Component WILL get called
        // this.ChildItems = 
        // [
        //     ...this.ChildItems,
        //     this.NewItem
        // ]
        this.NewItem = "";
    };
    ParentComponent.prototype.ngAfterContentInit = function () {
        console.log("Parent: ngAfterContentInit");
    };
    ParentComponent.prototype.ngAfterContentChecked = function () {
        console.log("Parent: ngAfterContentChecked");
    };
    // View
    ParentComponent.prototype.ngAfterViewInit = function () {
        console.log("Parent: ngAfterViewInit");
        //this.renderer.setElementStyle(this,"background","yellow");
    };
    ParentComponent.prototype.ngAfterViewChecked = function () {
        console.log("Parent: ngAfterViewChecked");
    };
    ParentComponent = __decorate([
        core_1.Component({
            selector: 'parent',
            moduleId: module.id,
            templateUrl: "ParentTemplate.html"
        }),
        __metadata("design:paramtypes", [core_1.Renderer])
    ], ParentComponent);
    return ParentComponent;
}());
exports.ParentComponent = ParentComponent;
//# sourceMappingURL=ParentComponent.js.map