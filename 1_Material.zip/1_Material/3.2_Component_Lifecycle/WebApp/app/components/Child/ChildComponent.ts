import { Component, SimpleChanges, Input, Renderer, ElementRef } from '@angular/core';

// Decorator
@Component(
    {
        selector : 'child',
        moduleId : module.id,
        templateUrl : "ChildTemplate.html" 
    }
)

export class ChildComponent
{
    // -----------------------------STATE---------------------------------- //

    @Input() Items : string[];
    InternalItems : string[]
    RefreshCounter : number;

    // All variables with static (default) values has to be initialized here
    // ElementRef v/s Renderer : Renderer acts on the DOM and ElementRef is a reference to an element in the DOM the Renderer acts on
    // The Renderer is a class that is a partial abstraction over the DOM. 
    // Using the Renderer for manipulating the DOM doesn't break server-side rendering or Web Workers (where direct access to the DOM would break)
    constructor(private element : ElementRef, private renderer: Renderer)
    {
        console.log("constructor");

        this.Items = [];
        this.InternalItems = 
        [
            "Apple",
            "Sony",
            "Panasonic"
        ];
        this.RefreshCounter = 0;
    }

    // All variables with dynamic values has to be initialized here
    ngOnInit() 
    {
        console.log("ngOnInit");
    }

    // Will get called only if memory reference of any Input variables are changed
    ngOnChanges(updates:SimpleChanges) 
    {
        console.log("ngOnChanges");
        //console.dir(updates);
    }

    // ------------------------------ACTION--------------------------------- //

    //Will get called once per Change Detection Cycle
    ngDoCheck()
    {
        if( this.RefreshCounter > 0)
        {
            console.groupEnd();
            console.group("Change Detection Iteration #" + this.RefreshCounter);
        }
        this.RefreshCounter =   this.RefreshCounter + 1;
    
        console.log("ngDoCheck");
    }

    // Clean up of any external resources
    ngDestroy()
    {
        console.log("ngDestroy");
    }

    // --------------------------------BUILD: FIRST TIME------------------------------- //

    // Content is what is passed as children. 
    // View is the template of the current component.

    // Called only ONCE
    // Content (Imported alient content)
    // View won't be available for modification at this stage
    ngAfterContentInit()
    {
        console.log("Child: ngAfterContentInit");

        // CONTENT
        //this.UpdateContentUsingElementRef();
        //this.UpdateContentUsingRenderer();

        // VIEW
        // var childSelfContent = this.element.nativeElement.querySelector("#ChildSelfContent");
        // console.log(childSelfContent.innerHTML);
    }

    // Called only ONCE
    // View (Complete template of the Component including the alien content)
    ngAfterViewInit()
    {
        console.log("Child: ngAfterViewInit");

        // CONTENT
        //this.UpdateContentUsingElementRef();
        //this.UpdateContentUsingRenderer();

        // VIEW
        // var childSelfContent = this.element.nativeElement.querySelector("#ChildSelfContent");
        // console.log(childSelfContent.innerHTML);

        // This is the perfect place to hock up any non-angular plugins/widgets such as jQuery plugins/kendo UI widgets

    }

    private UpdateContentUsingElementRef()
    {
        var ulElement = this.element.nativeElement.querySelector("ul");

        ulElement.classList.add("list");

        var listElements = ulElement.querySelectorAll("li");

        listElements.forEach(
            (liElement) => 
            {
                liElement.style.color = "white";

                // CAUTION: 
                // When attaching Event Listeners in ngAfterContentChecked 
                // since raising events will invoke change detection 
                // because DOM events are also monkey patched by Zones

                // liElement.addEventListener(
                //     "mouseover",
                //     () => 
                //     {
                //         liElement.style.background = "yellow";
                //     }
                // )
                
                // liElement.addEventListener(
                //     "mouseout",
                //     () => 
                //     {
                //         liElement.style.background = "";
                //     }
                // )
            }
        )
    }

     private UpdateContentUsingRenderer()
    {
        var ulElement = this.element.nativeElement.querySelector("#ChildComponentList");
         
        // Using Render instead of Native DOM Manipulation
        this.renderer.setElementClass(ulElement,"list",true);
        
        var listElements = ulElement.querySelectorAll("li");
        
        listElements.forEach(
            (liElement) => 
            {
                 // Using Render instead of Native DOM Manipulation
                 this.renderer.setElementStyle(liElement,"color","white");
            }
        )
    }
    
    // ----------------------------BUILD: Subsequence Times (ONCE per Change Detection Cycle) ---------------------------- //
    
    // Called: ONCE per Change Detection Cycle
    // Content: Latest Content Available
    // View: From last init or last update available
    ngAfterContentChecked()
    {
        console.log("Child: ngAfterContentChecked");

        // CONTENT
        //this.UpdateContentUsingElementRef();
    }

    // Called: ONCE per Change Detection Cycle
    // Content: Updated Available
    // View: Updated Available
    ngAfterViewChecked()
    {
        console.log("Child: ngAfterViewChecked");
        
        // VIEW: Child Component's Self Template
        //var childSelfContent = this.element.nativeElement.querySelector("#ChildSelfContent");
        //console.log(childSelfContent.innerHTML);

        // VIEW: Complete Component
        //console.log(this.element.nativeElement.innerHTML);
    }

    // --------------------------------------------------------------------- //
}

