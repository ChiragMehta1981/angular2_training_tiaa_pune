/*Angular Modules*/
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

/*Custom Modules*/
import { ParentComponent } from '../components/Parent/ParentComponent';
import { ChildComponent } from '../components/Child/ChildComponent';

// Decorator
@NgModule(
    {
        imports:      [ BrowserModule, FormsModule ], 
        declarations: [ ParentComponent, ChildComponent ],
        bootstrap:    [  ParentComponent  ] 
    }
)

// ES6 Class
export class AppModule 
{
}
