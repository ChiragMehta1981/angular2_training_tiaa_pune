import { Component, ViewEncapsulation, Input } from '@angular/core';
import Product from '../../models/ProductModel'; //Default Import

// Decorator
@Component(
    {
        moduleId : module.id, 
        selector : 'product-list',
        templateUrl : "ProductListTemplate.html" ,
        encapsulation : ViewEncapsulation.Emulated 
    }
)

export class ProductListComponent
{
    // Type Declarations:
    @Input() Products : Product[];

    constructor()
    {
        this.Products = [];
    }
   
    ngOnInit() 
    {
    }
}

