import { Component, ViewEncapsulation } from '@angular/core';

// Decorator
@Component(
    {
        moduleId : module.id, 
        selector : 'inventory',
        templateUrl : "InventoryTemplate.html" ,
        encapsulation : ViewEncapsulation.Emulated // Default
   
    }
)

export class InventoryComponent
{
    // Type Declarations:

    constructor()
    {
    }
   
    ngOnInit() // Event Handler for Init Event of Component
    {
    }
}

