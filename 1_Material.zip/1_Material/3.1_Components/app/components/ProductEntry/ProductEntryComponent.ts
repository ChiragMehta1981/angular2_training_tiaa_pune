import { Component, ViewEncapsulation, EventEmitter, Output, Input } from '@angular/core';
import Product from '../../models/ProductModel'; //Default Import
import { SaveStatusCodes } from "../../enums/SaveStatusCodes";

// Decorator
@Component(
    {
        moduleId : module.id, 
        selector : 'product-entry',
        templateUrl : "ProductEntryTemplate.html" ,
        encapsulation : ViewEncapsulation.Emulated // Default
   
    }
)

export class ProductEntryComponent
{
    // Type Declarations:
    @Input() SaveStatusNotification : EventEmitter<SaveStatusCodes>;
    @Output() OnSave : EventEmitter<Product>; // OnSave is an event which will be raised from Child Component
    NewProduct : Product;

    // Initialization
    constructor()
    {
       this.NewProduct = new Product();
       this.OnSave = new EventEmitter<Product>();
       this.SaveStatusNotification = new EventEmitter<SaveStatusCodes>();
    }
   
    ngOnInit() // Event Handler for Init Event of Component
    {
         this.SaveStatusNotification.subscribe(
             (savedStatus) => 
             {  
                 if (savedStatus == SaveStatusCodes.Saved) 
                 {
                        this.NewProduct = new Product();
                        alert("Product saved successfully");
                 }
                 else if (savedStatus == SaveStatusCodes.Duplicate) 
                 {
                        alert("Product already exists");
                 }
                 else if (savedStatus == SaveStatusCodes.Invalid) 
                 {
                        alert("Invalid product details");
                 }
             }
         )
    }

    SaveProduct()
    {
        this.OnSave.emit( this.NewProduct );
    }


}

