import { Component, ViewEncapsulation, Input, EventEmitter } from '@angular/core';
import Product from '../../models/ProductModel'; //Default Import
import {SaveStatusCodes} from '../../enums/SaveStatusCodes';

// Decorator
@Component(
    {
        moduleId : module.id, 
        selector : 'products',
        templateUrl : "ProductsTemplate.html" ,
        encapsulation : ViewEncapsulation.Emulated // Default
    }
)

export class ProductsComponent
{
    // Type Declarations:
    Products : Product[];
    OnSaveComplete : EventEmitter<SaveStatusCodes>;

    constructor()
    {
        this.Products = [];
        this.OnSaveComplete = new EventEmitter<SaveStatusCodes>();
    }
   
    ngOnInit() // Event Handler for Init Event of Component
    {
       // Suppose to call the web server to get Product List from DB
       
       // Mock / Stub Data
       this.Products = 
       [
           new Product("iPhone","Apple",5),
           new Product("Tab","Samsung",3),
           new Product("XBox","Microsoft",4)
       ]
    }

    SaveProductToList(newProduct : Product)
    {
        var result = this.Products.find(
            (product : Product) => 
            {
                return product.Name.toLowerCase() == newProduct.Name.toLowerCase();
            }
        )

        if(result) // Duplicate Product
        {
            this.OnSaveComplete.emit(SaveStatusCodes.Duplicate);
        }
        else // Unique Product
        {
            this.Products.push( newProduct );
            this.OnSaveComplete.emit(SaveStatusCodes.Saved);
        }
    }

  
}

