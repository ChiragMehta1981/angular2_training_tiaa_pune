"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Product = /** @class */ (function () {
    function Product(name, brand, rating) {
        if (name === void 0) { name = ""; }
        if (brand === void 0) { brand = ""; }
        if (rating === void 0) { rating = 3; }
        this.Name = name;
        this.Brand = brand;
        this.Rating = rating;
    }
    return Product;
}());
var ProductDetails = /** @class */ (function () {
    function ProductDetails() {
    }
    return ProductDetails;
}());
//export { Product }; // Named Export
exports.default = Product; // Default Export
//# sourceMappingURL=ProductModel.js.map