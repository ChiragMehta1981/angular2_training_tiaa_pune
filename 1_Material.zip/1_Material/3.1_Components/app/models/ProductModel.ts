
class Product
{
    Name : string;
    Brand : string;
    Rating : number; //1 To 5

    constructor(name="", brand="", rating=3)
    {
        this.Name = name;
        this.Brand = brand;
        this.Rating = rating;
    }
}

class ProductDetails
{
    constructor()
    {
    }
}

//export { Product }; // Named Export
export default Product; // Default Export