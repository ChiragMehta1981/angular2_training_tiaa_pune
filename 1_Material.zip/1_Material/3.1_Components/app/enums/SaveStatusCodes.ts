
export enum SaveStatusCodes
{
    Saved,
    Duplicate,
    Invalid
}