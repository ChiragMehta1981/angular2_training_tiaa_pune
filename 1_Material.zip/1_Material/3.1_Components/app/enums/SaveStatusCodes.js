"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SaveStatusCodes;
(function (SaveStatusCodes) {
    SaveStatusCodes[SaveStatusCodes["Saved"] = 0] = "Saved";
    SaveStatusCodes[SaveStatusCodes["Duplicate"] = 1] = "Duplicate";
    SaveStatusCodes[SaveStatusCodes["Invalid"] = 2] = "Invalid";
})(SaveStatusCodes = exports.SaveStatusCodes || (exports.SaveStatusCodes = {}));
//# sourceMappingURL=SaveStatusCodes.js.map