import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './modules/appModule';

const platform = platformBrowserDynamic();
platform.bootstrapModule(AppModule);
