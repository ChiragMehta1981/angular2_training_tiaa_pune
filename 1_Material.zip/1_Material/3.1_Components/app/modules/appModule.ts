/*Angular Modules*/
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from "@angular/forms";

/*Custom Modules*/
import { InventoryComponent } from '../components/Inventory/InventoryComponent';
import { ProductsComponent } from '../components/Products/ProductsComponent';
import { ProductListComponent } from '../components/ProductList/ProductListComponent';
import { ProductEntryComponent } from '../components/ProductEntry/ProductEntryComponent';

// Decorator
@NgModule(
    {
        imports:      
        [ 
            BrowserModule, 
            FormsModule 
        ], 
        
        declarations: 
        [ 
            InventoryComponent,
            ProductsComponent,
            ProductListComponent,
            ProductEntryComponent
        ], 
        
        bootstrap:    
        [ 
            InventoryComponent
        ]
    }
)

// ES6 Class
export class AppModule 
{
}
