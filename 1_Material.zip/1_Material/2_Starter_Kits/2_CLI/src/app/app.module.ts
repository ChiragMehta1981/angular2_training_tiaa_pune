import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ProductGalleryComponent } from './components/product-gallery/product-gallery.component';

@NgModule(

  {
    declarations:
    [
      AppComponent,
      ProductGalleryComponent
    ],

    imports:
    [
      BrowserModule
    ],

    providers:
    [

    ],

    bootstrap:
    [
      AppComponent
    ]

  }

)

export class AppModule { }
