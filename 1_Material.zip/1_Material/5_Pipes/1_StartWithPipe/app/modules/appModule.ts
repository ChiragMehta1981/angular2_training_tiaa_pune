/*Angular Modules*/
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

/*Components*/
import { AppComponent } from '../components/appComponent';

/*Custom Directives*/
import { StartsWithPipe } from '../pipes/StartsWithPipe';

// Decorator
@NgModule(
    {
        imports: 
        [ 
            BrowserModule,
            FormsModule
        ],
        
        declarations: 
        [ 
            AppComponent,
            StartsWithPipe
        ],
        
        bootstrap: [  AppComponent  ],
    }
)

// ES6 Class
export class AppModule 
{
}
