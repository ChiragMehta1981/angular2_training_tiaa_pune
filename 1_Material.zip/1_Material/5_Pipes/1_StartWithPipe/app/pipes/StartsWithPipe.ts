import { Pipe, PipeTransform } from '@angular/core';

@Pipe(
    {
        name : "startsWith"
    }
)

export class StartsWithPipe implements PipeTransform
{
    constructor() 
    {   
    }

    transform(value:string[],args:string[]) : any[]
    {
        var propertyName = args[0];
        var searchKey = args[1].toUpperCase();

        var transformedValue = value.filter(
            function(item:string)
            {
                var firstChar = item[propertyName].charAt(0).toUpperCase();
                
                if(searchKey == "")
                {
                    return true;
                }
                else
                {
                    return firstChar == searchKey;
                }
            }
        )
        
        return transformedValue;
    }
}


