"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var QuickInfoDirective = (function () {
    function QuickInfoDirective(el) {
        this.el = el;
        //console.dir(this.el);
    }
    QuickInfoDirective.prototype.OnMouseOver = function () {
        //var target = this.el.nativeElement;
        //console.dir(target);
        //var text = target.innerText;
        //console.log(text);
        var description = this.el.nativeElement.getAttribute("quickInfo");
        //console.log(description);
        this.dialogElement = document.createElement("div");
        this.dialogElement.innerText = description;
        this.dialogElement.style.display = "inline-block";
        this.dialogElement.style.minWidth = "50px";
        this.dialogElement.style.minHeight = "50px";
        this.dialogElement.style.margin = "10px";
        this.dialogElement.style.padding = "10px";
        this.dialogElement.style.background = "yellow";
        this.dialogElement.style.boxShadow = "1px 1px 2px 2px gray";
        if (this.el.nativeElement.parentNode) {
            this.el.nativeElement.parentNode.insertBefore(this.dialogElement, this.el.nativeElement.nextSibling);
        }
    };
    QuickInfoDirective.prototype.OnMouseLeave = function () {
        if (this.dialogElement) {
            var target = this.el.nativeElement;
            target.parentNode.removeChild(this.dialogElement);
        }
    };
    return QuickInfoDirective;
}());
__decorate([
    core_1.HostListener("mouseover"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], QuickInfoDirective.prototype, "OnMouseOver", null);
__decorate([
    core_1.HostListener("mouseleave"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], QuickInfoDirective.prototype, "OnMouseLeave", null);
QuickInfoDirective = __decorate([
    core_1.Directive({
        selector: "[quickInfo]"
    }),
    __metadata("design:paramtypes", [core_1.ElementRef])
], QuickInfoDirective);
exports.QuickInfoDirective = QuickInfoDirective;
//# sourceMappingURL=quickInfoDirective.js.map