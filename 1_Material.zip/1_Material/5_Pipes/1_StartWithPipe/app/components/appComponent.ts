
import { Component } from '@angular/core';
//import { TextToSpeechDirective } from '../directives/textToSpeechDirective';

// Decorator
@Component(
    {
        moduleId : module.id,
        selector : "app",
        templateUrl : "appTemplate.html",
        styleUrls : [ "appStyle.css" ]
    }
)

export class AppComponent
{   
    private Cars : object[];
    private FilterKey : string;

    constructor()
    {
        this.Cars = 
        [
            {
                Name : "City",
                Brand : "Honda"
            },
            {
                Name : "Innova",
                Brand : "Toyota"
            },
            {
                Name : "Corolla",
                Brand : "Toyota"
            },
            {
                Name : "Camry",
                Brand : "Toyota"
            },
            {
                Name : "Ciaz",
                Brand : "Suzuki"
            },
            {
                Name : "Jetta",
                Brand : "VW"
            }
        ]

        this.FilterKey = "";
    }
}

