/*Angular Modules*/
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

/*Custom Modules*/
// import { ParentComponent } from '../components/Parent/ParentComponent';
// import { ChildComponent } from '../components/Child/ChildComponent';
import { ListComponent } from '../components/List/ListComponent';

import {AgGridModule} from "ag-grid-angular/main";

// Decorator
@NgModule(
    {
        imports:      
        [ 
            BrowserModule, 
            FormsModule,
            AgGridModule.withComponents([])
        ], 
        declarations: 
        [ 
            ListComponent
        ],
        bootstrap: 
        [  
            ListComponent  
        ] 
    }
)

// ES6 Class
export class AppModule 
{
}
