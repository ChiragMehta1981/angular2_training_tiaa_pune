import { Component } from '@angular/core';

// Decorator
@Component(
    {
        moduleId : module.id,
        selector : 'ws-app',
        templateUrl : "AppTemplate.html"
    }
)

export class AppComponent
{    
    constructor()
    {

    }

    SaveUser(formValue)
    {
        alert( formValue.Name );
        sessionStorage.setItem("User",JSON.stringify(formValue))
    }

    Test()
    {
        console.log("Test Called");
        alert("Test Called");
        sessionStorage.setItem("Test", new Date().toLocaleTimeString() );
    }


}

