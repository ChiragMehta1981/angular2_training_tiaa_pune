import { FormsModule } from "@angular/forms";

import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { AppComponent } from './AppComponent';

describe(
  'AppComponent',
  function () {
    let debugElement: DebugElement;

    let appComponentFixture: ComponentFixture<AppComponent>;
    let appComponent: AppComponent;

    let form: HTMLElement = null;
    let nameField: HTMLInputElement = null;
    let ageField: HTMLInputElement = null;
    let saveButton: HTMLInputElement = null;
    let testButton: HTMLInputElement = null;

    // Creating a Mock Module with all the components which needs to be tested
    beforeEach(
       async (
          () => 
        {
          TestBed.configureTestingModule(
            {
              imports: [FormsModule],
              declarations: [AppComponent]
            }
          ).compileComponents();

          //done();
        }
       )
    );

    // Creating the Component to be tested
    // Do not re-configure TestBed after calling createComponent
    beforeEach(
      async(
        () => {
          appComponentFixture = TestBed.createComponent(AppComponent);

          appComponent = appComponentFixture.componentInstance;

          // If Model Changes then notify Angular to detect those changes and update the view
          appComponentFixture.detectChanges();
        }
      )
    );

    it(
      'Should create component',
      () => {
        expect(appComponent).toBeDefined()
      }
    );

    it(
      'should have expected <h1> text',
      () => {


        debugElement = appComponentFixture.debugElement.query(
          By.css(
            'h1'
          )
        );

        const h1 = debugElement.nativeElement;

        expect(h1.innerText).toEqual('Registration');
      }
    );

    it(
      'should have a valid form with appropriate fields',
      async(
        () => {

          debugElement = appComponentFixture.debugElement.query(
            By.css(
              'form'
            )
          );

          form = debugElement.nativeElement;

          nameField = appComponentFixture.debugElement.query(
            By.css(
              "form input[name='Name']"
            )
          ).nativeElement;

          ageField = appComponentFixture.debugElement.query(
            By.css(
              "form input[name='Age']"
            )
          ).nativeElement;

          saveButton = appComponentFixture.debugElement.query(
            By.css(
              "form input[type='submit']"
            )
          ).nativeElement;

          testButton = appComponentFixture.debugElement.query(
            By.css(
              "form input[id='btnTest']"
            )
          ).nativeElement;
          
          expect(form).not.toBeNull();
          expect(nameField).not.toBeNull();
          expect(ageField).not.toBeNull();
          expect(saveButton).not.toBeNull();
          expect(testButton).not.toBeNull();
        }
      )

    );

    it(
      'should register a User using the form',
     async () => 
      {
        //sessionStorage.clear();
        
        nameField.value = "John";
        nameField.dispatchEvent(new Event('input'));
        appComponentFixture.detectChanges();
        
        ageField.value = "25";
        ageField.dispatchEvent(new Event('input'));
        appComponentFixture.detectChanges();
        
        spyOn(appComponent, 'Test');
        // var testButtonDebugElement = appComponentFixture.debugElement.query(
        //   By.css(
        //     "input[id='btnTest']"
        //   )
        // );
        var testButtonDebugElement = appComponentFixture.debugElement.query(
          By.css(
            "#btnTest"
          )
        );
        console.dir(appComponent);
        testButtonDebugElement.nativeElement.click();
        //testButtonDebugElement.click();
        appComponentFixture.detectChanges();
        expect(appComponent.Test).toHaveBeenCalled();

        appComponent.Test();

        // appComponentFixture.whenStable().then(
        //   () => 
        //   {
        //     appComponentFixture.detectChanges();
        //     var storedUser = sessionStorage.getItem("User");
        //     expect(storedUser).not.toBeNull();
        //   }
        // )
      }
      
    );

  }
);
