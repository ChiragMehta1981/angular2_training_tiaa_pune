/*Angular Modules*/
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

/*Custom Modules*/
import { AppComponent } from '../components/AppComponent/AppComponent';

// Decorator
@NgModule(
    {
        imports:      [ BrowserModule, FormsModule, HttpModule ], // Aggregating all modules into AppModule
        declarations: [ AppComponent ], // All Components within the Component Tree
        bootstrap:    [  AppComponent  ] // Root of the Component Tree
    }
)

// ES6 Class
export class AppModule 
{
}
