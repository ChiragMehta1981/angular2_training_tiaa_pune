
import { Injectable } from "@angular/core";
import { Http } from '@angular/http';
import Product from '../models/ProductModel'; //Default Import

@Injectable()

export class DataService {
    // Type Declarations
    ProductList: Product[];
    RestEndpoints: any;

    constructor(private httpService: Http) {
        this.ProductList = [];

        this.RestEndpoints =
            {
                Products: "http://localhost:5000/Products/",
                ProductPricing : "http://localhost:5000/ProductCosting/",
                Services: "http://localhost:5000/Services/",
            }
    }

    GetProducts() {
        return new Promise(
            (successCb, errorCb) => 
            {
                // FIRST CALL
                var httpObservable = this.httpService.get(
                    this.RestEndpoints.Products
                )

                httpObservable.subscribe(
                    (response) => {
                        var data = response.json();

                        this.ProductList = data.map(
                            (item) => {
                                return new Product(
                                    item.Name,
                                    item.Brand,
                                    item.Rating,
                                    item.id
                                )
                            }
                        )

                        // SECOND CALL
                        var httpObservable2 = this.httpService.get(
                            this.RestEndpoints.ProductPricing
                        )

                        httpObservable2.subscribe(
                            (response) => // NEXT
                            {
                                var productPricingData : any[] = response.json();
                               
                               productPricingData.forEach(
                                   (item) => 
                                   {
                                        var productMatched = this.ProductList.find(
                                            (product) => 
                                            {
                                                return product.id == item.ProductId;
                                            }
                                        )
                                        
                                        productMatched.Price = item.Price;
                                   }
                               )

                               successCb( this.ProductList ); // => Data => COmponent

                            }
                        )
                    },
                    (err) => {
                        console.log(err);
                    }
                )
            }
        )

    }

    AddProduct() {

    }
}