import { Component, ViewEncapsulation, Input, EventEmitter } from '@angular/core';
import Product from '../../models/ProductModel'; //Default Import
import {SaveStatusCodes} from '../../enums/SaveStatusCodes';
import { Http } from '@angular/http'; // Http Object
import { DataService } from '../../services/DataService';

// Decorator
@Component(
    {
        moduleId : module.id, 
        selector : 'products',
        templateUrl : "ProductsTemplate.html" ,
        encapsulation : ViewEncapsulation.Emulated // Default
    }
)

export class ProductsComponent
{
    // Type Declarations:
    Products : Product[];
    OnSaveComplete : EventEmitter<SaveStatusCodes>;
  
    constructor(private http : Http, private dataService : DataService) // Dependency Injection
    {
        this.Products = [];
        this.OnSaveComplete = new EventEmitter<SaveStatusCodes>();
    }
   
    ngOnInit() // Event Handler for Init Event of Component
    {
        var promise = this.dataService.GetProducts();

        promise.then(
            (productList : Product[]) => 
            {
                this.Products = productList;
            },
            () =>
            {

            }
        )
       
    }

    SaveProductToList(newProduct : Product)
    {
        var result = this.Products.find(
            (product : Product) => 
            {
                return product.Name.toLowerCase() == newProduct.Name.toLowerCase();
            }
        )

        if(result) // Duplicate Product
        {
            this.OnSaveComplete.emit(SaveStatusCodes.Duplicate);
        }
        else // Unique Product
        {
            //this.Products.push( newProduct );
            
            //Call the Rest API Here
            var httpObservable = this.http.post(
                "http://localhost:5000/Products", // RestAPI Endpoint => URL
                newProduct //=> BODY
            )

            httpObservable.subscribe(
                (response) => // NEXT
                {
                    var addedProduct = response.json(); // Product / Object
                    newProduct.id = addedProduct.id;
                    this.Products.push(newProduct);
                },
                (err) => // ERR
                {
                    console.dir(err);
                },
                () => // COMPLETE
                {
                    this.OnSaveComplete.emit(SaveStatusCodes.Saved);
                }
            )
        }
    }

  
}

