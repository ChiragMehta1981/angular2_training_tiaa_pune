"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ProductModel_1 = require("../../models/ProductModel"); //Default Import
var SaveStatusCodes_1 = require("../../enums/SaveStatusCodes");
// Decorator
var ProductEntryComponent = (function () {
    // Initialization
    function ProductEntryComponent() {
        this.NewProduct = new ProductModel_1.default();
        this.OnSave = new core_1.EventEmitter();
        this.SaveStatusNotification = new core_1.EventEmitter();
    }
    ProductEntryComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.SaveStatusNotification.subscribe(function (savedStatus) {
            if (savedStatus == SaveStatusCodes_1.SaveStatusCodes.Saved) {
                _this.NewProduct = new ProductModel_1.default();
                alert("Product saved successfully");
            }
            else if (savedStatus == SaveStatusCodes_1.SaveStatusCodes.Duplicate) {
                alert("Product already exists");
            }
            else if (savedStatus == SaveStatusCodes_1.SaveStatusCodes.Invalid) {
                alert("Invalid product details");
            }
        });
    };
    ProductEntryComponent.prototype.SaveProduct = function () {
        this.OnSave.emit(this.NewProduct);
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", core_1.EventEmitter)
    ], ProductEntryComponent.prototype, "SaveStatusNotification", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", core_1.EventEmitter)
    ], ProductEntryComponent.prototype, "OnSave", void 0);
    ProductEntryComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'product-entry',
            templateUrl: "ProductEntryTemplate.html",
            encapsulation: core_1.ViewEncapsulation.Emulated // Default
        }),
        __metadata("design:paramtypes", [])
    ], ProductEntryComponent);
    return ProductEntryComponent;
}());
exports.ProductEntryComponent = ProductEntryComponent;
//# sourceMappingURL=ProductEntryComponent.js.map