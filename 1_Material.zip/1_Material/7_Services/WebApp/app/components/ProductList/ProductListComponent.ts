import { Component, ViewEncapsulation, Input } from '@angular/core';
import Product from '../../models/ProductModel'; //Default Import
import {Observable} from 'rxjs/Observable';

// Decorator
@Component(
    {
        moduleId : module.id, 
        selector : 'product-list',
        templateUrl : "ProductListTemplate.html" ,
        encapsulation : ViewEncapsulation.Emulated 
    }
)

export class ProductListComponent
{
    // Type Declarations:
    @Input() Products : Product[];

    constructor()
    {
        this.Products = [];
    }
   
    ngOnInit() 
    {
        // var counter = 0;

        // var ob = new Observable(
        //     (observable) =>
        //     {
        //          var timerId = setTimeout(
        //             () => 
        //             {
        //                 counter = counter + 1;
        //                 console.log(counter);

        //                 if(counter > 3)
        //                 {
        //                     observable.complete();
        //                     clearInterval(timerId);
        //                 }
        //                 else
        //                 {
        //                     var data = new Date().toLocaleTimeString();
        //                     observable.next( data );
        //                 }
        //             },
        //             3000
        //         )
        //     }
        // );

        // ob.subscribe(
        //     () =>  // OnNext
        //     {
        //         console.log("Sub 1: Next");
        //     },
        //     () => // OnErr
        //     {

        //     },
        //     () => //OnComplete
        //     {
        //         console.log("Sub 1: Completed");    
        //     }
        // )

        // ob.subscribe(
        //     () =>  // OnNext
        //     {
        //         console.log("Sub 2: Next");
        //     },
        //     () => // OnErr
        //     {

        //     },
        //     () => //OnComplete
        //     {
        //         console.log("Sub 2: Completed");    
        //     }
        // )
       
    }
}

