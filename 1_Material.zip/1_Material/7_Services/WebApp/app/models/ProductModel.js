"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Product = (function () {
    function Product(name, brand, rating, id, price) {
        if (name === void 0) { name = ""; }
        if (brand === void 0) { brand = ""; }
        if (rating === void 0) { rating = 3; }
        if (id === void 0) { id = 0; }
        if (price === void 0) { price = 0; }
        this.Name = name;
        this.Brand = brand;
        this.Rating = rating;
        this.id = id;
        this.Price = price;
    }
    return Product;
}());
var ProductDetails = (function () {
    function ProductDetails() {
    }
    return ProductDetails;
}());
//export { Product }; // Named Export
exports.default = Product; // Default Export
//# sourceMappingURL=ProductModel.js.map