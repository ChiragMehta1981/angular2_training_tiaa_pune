
class Product
{
    Name : string;
    Brand : string;
    Rating : number; //1 To 5
    id : number;
    Price : number;

    constructor(name="", brand="", rating=3, id=0, price=0)
    {
        this.Name = name;
        this.Brand = brand;
        this.Rating = rating;
        this.id = id;
        this.Price = price;
    }
}

class ProductDetails
{
    constructor()
    {
    }
}

//export { Product }; // Named Export
export default Product; // Default Export