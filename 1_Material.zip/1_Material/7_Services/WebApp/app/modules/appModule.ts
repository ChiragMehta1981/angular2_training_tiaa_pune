/*Angular Modules*/
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from "@angular/forms";
import { HttpModule } from "@angular/http";

/*Custom Modules*/
import { InventoryComponent } from '../components/Inventory/InventoryComponent';
import { ProductsComponent } from '../components/Products/ProductsComponent';
import { ProductListComponent } from '../components/ProductList/ProductListComponent';
import { ProductEntryComponent } from '../components/ProductEntry/ProductEntryComponent';

// Custom Services
import { DataService } from '../services/DataService';

// Decorator
@NgModule(
    {
        imports:      
        [ 
            BrowserModule, 
            FormsModule,
            HttpModule // new Http Object
        ], 
        
        declarations: 
        [ 
            InventoryComponent,
            ProductsComponent,
            ProductListComponent,
            ProductEntryComponent
        ], 
        
        bootstrap:    
        [ 
            InventoryComponent
        ],

        providers :
        [
            DataService // single new instance of DataService will be created
        ]
    }
)

// ES6 Class
export class AppModule 
{
}
