
import { Component } from '@angular/core';
//import { TextToSpeechDirective } from '../directives/textToSpeechDirective';

// Decorator
@Component(
    {
        moduleId : module.id,
        selector : "app",
        templateUrl : "appTemplate.html",
        styleUrls : [ "appStyle.css" ]
    }
)

export class AppComponent
{   
    constructor()
    {
    }
}

