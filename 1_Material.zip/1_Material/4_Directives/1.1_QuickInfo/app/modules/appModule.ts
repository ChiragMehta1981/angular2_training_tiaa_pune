/*Angular Modules*/
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

/*Components*/
import { AppComponent } from '../components/appComponent';

/*Custom Directives*/
import { QuickInfoDirective } from '../directives/quickInfoDirective';

// Decorator
@NgModule(
    {
        imports: [ BrowserModule ],
        
        declarations: 
        [ 
            AppComponent,
            QuickInfoDirective
        ],
        
        bootstrap: [  AppComponent  ]
    }
)

// ES6 Class
export class AppModule 
{
}
