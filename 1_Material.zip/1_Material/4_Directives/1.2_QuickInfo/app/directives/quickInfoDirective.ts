import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive(
    {
        selector : "[quickInfo]"
    }
)

export class QuickInfoDirective 
{
    private dialogElement : any;
    
    constructor(private el: ElementRef) 
    {
        //console.dir(this.el);
    }

     @HostListener ("mouseover") OnMouseOver()
     {
        //var target = this.el.nativeElement;
        //console.dir(target);
        
        //var text = target.innerText;
        //console.log(text);

        var description = this.el.nativeElement.getAttribute("quickInfo");
        //console.log(description);

        this.dialogElement = document.createElement("div");
        this.dialogElement.innerText = description;
        this.dialogElement.style.display = "inline-block";
        this.dialogElement.style.minWidth = "50px";
        this.dialogElement.style.minHeight = "50px";
        this.dialogElement.style.margin = "10px";
        this.dialogElement.style.padding = "10px";
        this.dialogElement.style.background = "yellow";
        this.dialogElement.style.boxShadow = "1px 1px 2px 2px gray";
        if(this.el.nativeElement.parentNode)
        {
            this.el.nativeElement.parentNode.insertBefore(this.dialogElement, this.el.nativeElement.nextSibling);
        }
     }

     @HostListener ("mouseleave") OnMouseLeave()
     {
        if(this.dialogElement)
        {
            var target = this.el.nativeElement;
            target.parentNode.removeChild(this.dialogElement);
        }
     }
}


