
import { Component } from '@angular/core';
import { FormGroup , FormBuilder, Validators } from '@angular/forms';

// Decorator
@Component(
    {
        moduleId : module.id,
        selector : "app",
        templateUrl : "appTemplate.html",
        styleUrls : [ "appStyle.css" ]
    }
)

export class AppComponent
{
    RegistrationForm : FormGroup;
    
    constructor(formBuilder : FormBuilder)
    {
        this.RegistrationForm = formBuilder.group(
            {
                Name : 
                [ 
                    null, 
                    [ 
                        Validators.required
                    ]  
                ],
                Mobile: 
                [ 
                    null,
                    [
                        Validators.minLength(10),
                        Validators.maxLength(12)
                    ]
                ]
            }
        )
    }

    Register()
    {
        console.dir(this.RegistrationForm);
    }    
}

