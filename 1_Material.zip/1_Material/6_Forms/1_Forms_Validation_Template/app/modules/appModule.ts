/*Angular Modules*/
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

/*Custom Modules*/
import { AppComponent } from '../components/appComponent';

// Decorator
@NgModule(
    {
        imports:      [ BrowserModule, FormsModule ], // Aggregating all modules into AppModule
        declarations: [ AppComponent ], // All Components within the Component Tree
        bootstrap:    [  AppComponent  ]
    }
)

// ES6 Class
export class AppModule 
{
}
