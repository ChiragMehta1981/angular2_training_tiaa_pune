
import { Component } from '@angular/core';
import { FormGroup , FormControl, Validators } from '@angular/forms';

// Decorator
@Component(
    {
        moduleId : module.id,
        selector : "app",
        templateUrl : "appTemplate.html",
        styleUrls : [ "appStyle.css" ]
    }
)

export class AppComponent
{
    // RegistrationForm : FormGroup;
    
    constructor()
    {
        // this.RegistrationForm = new FormGroup(
        //     {
        //         Name : new FormControl(
        //             "Max",
        //             [
        //                 Validators.required
        //             ]
        //         ),
        //         Mobile : new FormControl(
        //             null,
        //             [
        //                 Validators.minLength(10),
        //                 Validators.maxLength(12)
        //             ]
        //         )
        //     }
        // );
    }

    Register(RegistrationFormValues:any)
    {
        console.dir(RegistrationFormValues);
    }    
}

