import { Component } from '@angular/core';

// Decorator
@Component(
    {
        selector : 'parent',
        moduleId : module.id,
        templateUrl : "ParentTemplate.html" 
    }
)

export class ParentComponent
{
    ValueA : string;
    ValueB : { TimeStamp : string }; // Object
    
    constructor()
    {
        this.ValueA = new Date().toLocaleTimeString();
        
        this.ValueB = 
        {
            TimeStamp : new Date().toLocaleTimeString()
        };
    }

    Update()
    {
        //this.ValueA = new Date().toLocaleTimeString();

        
        // Changing the ValueB Object's Content NOT memory reference of ValueB
        //this.ValueB.TimeStamp = new Date().toLocaleTimeString();
        
        // Changing the value of ValueB i.e.: Object Reference
        this.ValueB = 
        {
            TimeStamp : new Date().toLocaleTimeString()
        }
    }
}

