import { Component, SimpleChanges, Input, Renderer, ElementRef, ChangeDetectionStrategy } from '@angular/core';

// Decorator
@Component(
    {
        selector : 'child',
        moduleId : module.id,
        templateUrl : "ChildTemplate.html",
        changeDetection : ChangeDetectionStrategy.OnPush
    }
)

export class ChildComponent
{
    // -----------------------------STATE---------------------------------- //

   @Input() SimpleType : string;
   @Input() ComplexType : { TimeStamp : string };

    constructor()
    {
        console.log("constructor");

        this.SimpleType = "";
        
        this.ComplexType = 
        { 
            TimeStamp : "" 
        };
    }

    ngOnInit() 
    {
        console.log("ngOnInit");
    }

    ngOnChanges(updates:SimpleChanges) 
    {
        console.log("ngOnChanges");
        console.dir(updates);
    }

    ngDoCheck()
    {
        console.log("ngDoCheck");
    }

    ngAfterContentChecked()
    {
        console.log("Child: ngAfterContentChecked");
    }

    ngAfterViewChecked()
    {
        console.log("Child: ngAfterViewChecked");
    }
}

