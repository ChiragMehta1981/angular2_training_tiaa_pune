
// Modules
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

//Decorators
import { NgModule } from '@angular/core';

// Components
import { AppComponent } from './app.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { SubscriptionComponent } from './components/subscription/subscription.component';

@NgModule(

  {
    declarations:
    [
      AppComponent,
      RegistrationComponent,
      SubscriptionComponent
    ],

    imports:
    [
      BrowserModule,
      FormsModule,
      ReactiveFormsModule,
    ],

    bootstrap:
    [
      AppComponent
    ]

  }

)

export class AppModule { }
