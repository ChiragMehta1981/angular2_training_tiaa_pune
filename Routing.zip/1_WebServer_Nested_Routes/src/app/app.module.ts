
// Modules
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';

//Decorators
import { NgModule } from '@angular/core';

// Components
import { AppComponent } from './app.component';
import { CustomerListComponent }  from './components/customer-list/customer-list.component';
import { CustomerEntryComponent } from './components/customer-entry/customer-entry.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { SubscriptionComponent } from './components/subscription/subscription.component';
import { CustomerComponent } from './components/customer/customer.component';

// Directives
import { MarkerDirective } from './directives/MarkerDirective';

//Pipes
import { SortPipe } from './pipes/SortPipe';

//Services
import { MemoryDBService } from './services/MemoryDBService';
import { DataService } from './services/DataService';

//Routes
import { AppRoutes }  from './routes/AppRoutes';

@NgModule(

  {


    imports:
    [
      BrowserModule,
      FormsModule,
      ReactiveFormsModule,
      HttpModule,
      RouterModule.forRoot(AppRoutes)
    ],

    declarations:
    [
      AppComponent,
      CustomerListComponent,
      CustomerEntryComponent,
      MarkerDirective,
      SortPipe,
      RegistrationComponent,
      SubscriptionComponent,
      CustomerComponent
    ],

    exports :
    [
      //None to export
    ],

    providers:
    [
      MemoryDBService, // create new instance of MemoryDBService (singleton)
      DataService
    ],

    bootstrap:
    [
      AppComponent
    ],

    entryComponents: // List down components which will added dynamically (lazy loading of routes)
    [
      CustomerEntryComponent
    ]
  }

)

export class AppModule { }
