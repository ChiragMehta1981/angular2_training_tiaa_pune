
import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive(
  {
    selector : '[marker]' //<section marker></section>
  }
)

export class MarkerDirective
{
  private NativeElement : HTMLElement;
  private MarkerColor : { backgroundColor : string , color : string};

  constructor(private elementRef : ElementRef)
  {
    //console.dir(elementRef);
    //console.dir(elementRef.nativeElement); // div / section / h1 / app.component
    this.NativeElement = elementRef.nativeElement;
    this.MarkerColor =
    {
      backgroundColor : "yellow" ,
      color : "orange"
    };
  }

  ngOnInit()
  {
    var markerColorObj = this.NativeElement.getAttribute("marker");

    if(markerColorObj !== undefined)
    {
      this.MarkerColor = JSON.parse(markerColorObj);
    }
  }

  @HostListener("mouseover") HandleMouseOver()
  {
    this.NativeElement.style.backgroundColor = this.MarkerColor.backgroundColor;
    this.NativeElement.style.color = this.MarkerColor.color;
  }

  @HostListener("mouseout") HandleMouseOut()
  {
    this.NativeElement.style.backgroundColor = "";
    this.NativeElement.style.color = "";
  }
}
