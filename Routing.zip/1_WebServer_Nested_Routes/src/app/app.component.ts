
import { Component, ViewEncapsulation } from '@angular/core';
import CustomerModel from './models/CustomerModel';
import { Http, Headers } from '@angular/http';
import { MemoryDBService } from './services/MemoryDBService';


// Component Decorator
@Component(
  {
    selector: 'app-root',

    // template :
    // `
    //   <h1>
    //     JS
    //   </h1>
    // `,

    templateUrl: './app.component.html',

    // styles :
    // [
    //     `
    //     h1
    //       {
    //         margin: 10px;
    //         padding: 10px;
    //         border-style :solid;
    //         border-color : black;
    //         border-width: 1px;
    //         background-color:lightyellow;
    //       }
    //     `
    // ]

    // where to find the styles from
    styleUrls:
    [
      './app.component.css'
    ],

    // how styles should be applied
    encapsulation : ViewEncapsulation.Emulated
  }
)

// Data Model of the Component
export class AppComponent
{
  // Type Declarations
  private AppName : string;
  private AppVersion : number;
  private AppFeatures :string[];
  private LastLoadTime : string;
  private UserName : string;
  private NewFeature : string;
  private IsJSPowered : boolean;
  private HoverStyle : object; //{ a : string}
  private Customers : CustomerModel[];

  constructor(
    private httpService : Http,
    private memoryDBService : MemoryDBService
  )
  {
    this.AppName = "AppX";
    this.AppVersion = 4.0;
    this.AppFeatures =
    [
      "Helps us to understand Angular",
      "Creates Mock Components",
      "Communicates with REST APIs on the Web Server"
    ];
    this.LastLoadTime = new Date().toLocaleTimeString();
    this.UserName = "Max";
    this.NewFeature = "";
    this.IsJSPowered = true;
    this.HoverStyle =
    {
      backgroundColor : "blue" // background-color : "blue"
    };
    this.Customers =
    [
        // new CustomerModel("Max",50,"Pune"),
        // new CustomerModel("John",25,"Pune"),
        // new CustomerModel("Sally",35,"Mumbai")
    ];
  }

  ngOnInit()
  {
    var lastVisited = this.memoryDBService.Get("LastVisited");

    if(lastVisited !== null)
    {
      //alert("You last visited on: " + lastVisited);
    }

    lastVisited = new Date().toLocaleString();
    this.memoryDBService.Add("LastVisited" , lastVisited);
  }

  HandleHover(arg)
  {
    if(arg == false)
    {
      this.HoverStyle["backgroundColor"] = "red";
    }
    else if(arg == true)
    {
      this.HoverStyle["backgroundColor"] = "blue";
    }

  }

  HandleRefreshClick()
  {
    this.LastLoadTime = new Date().toLocaleTimeString();
  }

  HandleAddNewFeature()
  {
    this.AppFeatures.push( this.NewFeature );
    this.NewFeature = "";
  }

  HandleCustomerAdd(newCustomer)
  {
      // Serialization
      var data = JSON.stringify(newCustomer);

      var httpHeaders = new Headers();
      httpHeaders.append('content-type','application/json');

      var httpObservable = this.httpService.post(
        "http://localhost:90/Customers", // URL
        data, // BODY
        { //Configurations
          headers : httpHeaders
        }
      );

      httpObservable.subscribe(

          function next(httpResponse)
          {

            // Deserializing
            var customerAdded = httpResponse.json();
            //this.Customers.push(customerAdded);

            this.Customers =
            [
              ...this.Customers,
              customerAdded
            ];

          }.bind(this),

          function error(httpError)
          {
            console.log(httpError);
          },

          function completed()
          {
          }
      )

  }

}
