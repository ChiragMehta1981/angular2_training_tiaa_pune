import { Component, OnInit } from '@angular/core';
import { FormGroup , FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-subscription',
  templateUrl: './subscription.component.html',
  styleUrls: ['./subscription.component.css']
})
export class SubscriptionComponent implements OnInit {

  private SubscriptionForm : FormGroup;

  constructor() { }

  ngOnInit()
  {
      this.SubscriptionForm = new FormGroup(
        {
            Name : new FormControl(
                "", // Default Value
                [
                    Validators.required,
                    Validators.minLength(3)
                ]
            ),

            Age : new FormControl(
                18,
                [
                  Validators.required
                ]
            )
        }
      )
  }

  RegisterCustomer()
  {
    console.dir(this.SubscriptionForm.value);
  }

ngOnDestroy()
{
  console.log("Subscription component destroyed");
}


}
