import { Component, Input,SimpleChange } from '@angular/core';
import CustomerModel from '../../models/CustomerModel';
import { DataService } from '../../services/DataService';
import { Router } from '@angular/router';
import { CustomerEntryComponent} from '../customer-entry/customer-entry.component';

@Component(
  {
    selector: 'app-customer-list',
    templateUrl: './customer-list.component.html',
    styleUrls: ['./customer-list.component.css']
  }
)

export class CustomerListComponent
{
  //Type Declarations
  private ExistingCustomers : CustomerModel[];

  constructor(private dataService : DataService, private routerService : Router) // Dependency Injection (DI)
  {
    this.ExistingCustomers = [];
  }


  ngOnChanges(changes:SimpleChange)
  {
    // console.log("CustomerListComponent: ngOnChanges");
    // console.dir(changes);
  }

  ngDoCheck()
  {
    //console.log("Child Component: ngDoCheck");
  }

  ngOnDestroy()
  {
    //console.log("Child Component: Destroy");
  }

  ngAfterViewInit()
  {
    var promiseObj = this.dataService.GetCustomers();
    promiseObj.then(

      function success(customerList)
      {

        this.ExistingCustomers = customerList

      }.bind(this),

      function error()
      {

      }
    );
  }

}
