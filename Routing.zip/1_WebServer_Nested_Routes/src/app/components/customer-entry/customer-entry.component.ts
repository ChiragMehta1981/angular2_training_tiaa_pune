
import { Component, EventEmitter, Output } from '@angular/core';
import CustomerModel from '../../models/CustomerModel';
import { Router } from '@angular/router';

@Component(
  {
    selector: 'app-customer-entry',
    templateUrl: './customer-entry.component.html',
    styleUrls: ['./customer-entry.component.css']
  }
)

export class CustomerEntryComponent
{
  private NewCustomer : CustomerModel;
  @Output() public OnNewCustomerAdd : EventEmitter<CustomerModel>;

  constructor(private routerService : Router)
  {
    this.NewCustomer = new CustomerModel();
    this.OnNewCustomerAdd = new EventEmitter<CustomerModel>();
  }

  ngOnInit()
  {
    //console.log("CustomerEntryComponent : ngOnInit");
  }

  AddNewCustomer()
  {
    this.OnNewCustomerAdd.emit(this.NewCustomer);
    this.NewCustomer = new CustomerModel(); // Clean Up
  }

}
