
import { Injectable } from '@angular/core';
import CustomerModel from '../models/CustomerModel';
import { Http } from '@angular/http';

@Injectable()

export class DataService
{
  private CustomerList : CustomerModel[];

  constructor(private httpService : Http)
  {
    this.CustomerList = [];
  }

  GetCustomers()
  {
    return new Promise(

        function GetCustomersPromiseCallback(resolve,reject)
        {

           // Invoke HTTP Service
            // HTTP GET
            var httpObservable = this.httpService.get(
              "http://localhost:90/Customers"
            );

            httpObservable.subscribe(

                function next(httpResponse)
                {

                  // Deserializing
                  this.CustomerList = httpResponse.json(); // Array of Customer Objects

                  resolve(this.CustomerList);

                }.bind(this),

                function error(httpError)
                {
                  console.log(httpError);
                  reject("Server Error");
                },

                function completed()
                {
                }
            )

        }.bind(this)
    );
  }
}
