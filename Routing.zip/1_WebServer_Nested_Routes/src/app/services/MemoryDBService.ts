import { Injectable } from '@angular/core';


class MemoryKeyValue
{
  private Key : string;
  private Value : any;

  constructor(key,value)
  {
    this.Key = key;
    this.Value = value;
  }
}


@Injectable()

export class MemoryDBService
{
  private MemoryDB : any[];

  constructor()
  {
    this.MemoryDB = [];
    this.Sync();
  }

  Sync()
  {
    var result = window.localStorage.getItem("MemoryDB");

    if(result !== null)
    {
        this.MemoryDB = JSON.parse(result); // deserialize it
    }

  }

  Add(key,value)
  {
    console.dir(this.MemoryDB);

    var matchedItem = this.MemoryDB.find(
      function predicate(item)
      {
        var result = item.Key == key;
        return result; // true / false
      }
    )

    if(matchedItem === undefined) // First time (ADD)
    {
        var item = new MemoryKeyValue(key,value);
        this.MemoryDB.push(item);
    }
    else // modify existing (EDIT)
    {
      matchedItem.Value = value;
    }

    // Sync MemoryDB with Browser Local Storage
    window.localStorage.setItem(
      "MemoryDB",
      JSON.stringify(this.MemoryDB)
    )

  }

  Get(key)
  {
      var matchedItem = this.MemoryDB.find(
          function predicate(item)
          {
            var result = item.Key == key;
            return result; // true / false
          }
      )

      if(matchedItem !== undefined)
      {
        return matchedItem.Value;
      }
      else
      {
        return null;
      }
  }

}

