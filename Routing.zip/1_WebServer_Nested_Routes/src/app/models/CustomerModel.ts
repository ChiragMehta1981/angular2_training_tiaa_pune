
class CustomerModel
{
  Name : string;
  Age : number;
  City : string;

  constructor(name : string="" , age : number = 0 , city : string="")
  {
    this.Name = name;
    this.Age = age;
    this.City = city;
  }
}

export default CustomerModel;
