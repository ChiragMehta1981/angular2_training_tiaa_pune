
import { Pipe, PipeTransform } from '@angular/core';

@Pipe(
  {
    name : 'sort'
  }
)

export class SortPipe implements PipeTransform
{
  constructor()
  {

  }

  transform(param : any[] ,args: any[]) : any[]
  {
    var result = param;

    var sortKey = args[0]; // age
    var sorDirection = args[1]; // true / false

    //sorting logic
    result = result.sort(
      function predicate(current,next)
      {
        if(sorDirection == true)
        {
          return current[sortKey] - next[sortKey];
        }
        else
        {
          return next[sortKey] - current[sortKey];
        }
      }
    )


    return result;
  }

}
