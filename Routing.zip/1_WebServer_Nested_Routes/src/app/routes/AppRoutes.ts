

import { SubscriptionComponent } from '../components/subscription/subscription.component';
import { CustomerRoutes } from './CustomerRoutes';

 export const AppRoutes =
 [
    //http://localhost/
    {
      path : '', // landing page
      pathMatch : 'full', // exact url as //http://localhost/
      component : SubscriptionComponent
    },

    //http://localhost/register
    {
      path : 'register',
      component : SubscriptionComponent
    },

    ...CustomerRoutes
];

