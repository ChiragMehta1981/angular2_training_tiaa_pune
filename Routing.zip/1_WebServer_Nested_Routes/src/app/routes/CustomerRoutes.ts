

import { CustomerComponent } from '../components/customer/customer.component';
import { CustomerListComponent } from '../components/customer-list/customer-list.component';
import { CustomerEntryComponent } from '../components/customer-entry/customer-entry.component';

 export const CustomerRoutes =
 [

  //http://localhost/customer/
  {
    path : 'customer', // landing page
    component : CustomerComponent,
    children :
    [
        //http://localhost/customer/
        {
          path : '', // sub-landing page
          component : CustomerListComponent
        },

      //http://localhost/customer/customerslist
        {
          path : 'customerslist', // landing page
          component : CustomerListComponent
        },

        //http://localhost/customer/customersentry
        {
          path : 'customersentry',
          component : CustomerEntryComponent
        }
    ]
  },



];

